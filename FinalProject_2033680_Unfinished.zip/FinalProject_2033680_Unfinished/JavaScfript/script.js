$(document).ready(function() {
    // Sample data
    const items = ['apple', 'Banana', 'Cherry', 'Grapes', 'Orange', 'Pineapple'];
  
    // Event listener for the search input
    $('#searchInput').on('input', function() {
      // Clear previous search results
      $('#searchResults').empty();
  
      // Get the user's search query
      const query = $(this).val().toLowerCase();
  
      // Filter items based on the search query
      const filteredItems = items.filter(function(item) {
        return item.toLowerCase().includes(query);
      });
  
      // Display the filtered items
      filteredItems.forEach(function(item) {
        const listItem = $('<li>', { class: 'resultItem', text: item });
        $('#searchResults').append(listItem);
      });
    });
  });
  