$(document).ready(function(){

    var $username = "admin";
    var $password = "12345";

    $("#btn-login").on('click',function(){
        event.preventDefault();
        
        if($("#username").val() == $username && $("#password").val() == $password){
            alert("Welcome to my website!")
            window.location.href = "welcome.html";
        }
    })

})