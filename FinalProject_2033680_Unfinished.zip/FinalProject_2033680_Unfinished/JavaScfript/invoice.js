$(document).ready(function(){

    var mySubtotal = parseFloat(localStorage.getItem('mySubtotal'));
    var myQuantity = parseFloat(localStorage.getItem('myQuantity'));


    $("#totalBeforeTax").text(mySubtotal.toFixed(2));
    $("#totalQuantity").text(myQuantity);

    var subTotalValue = mySubtotal.toFixed(2);
    $("#subTotal").text("Subtotal: " + subTotalValue);

    var tpsValue = (mySubtotal * 0.05).toFixed(2);
    $("#tps").text("TPS: " + tpsValue);

    var tvqValue = (mySubtotal * 0.09975).toFixed(2);
    $("#tvq").text("TVQ: " + tvqValue);

    var totalValue = (mySubtotal + parseFloat(tpsValue) + parseFloat(tvqValue)).toFixed(2);
    $("#total").text("Total: " + totalValue);

    $("#totalPurchase").val(totalValue)
    if ($("#totalPurchase").val(NaN)){
        $("#totalPurchase").val("");
    }

    $("#clearButton").on('click', function(){
        $("#cardType").val("");
        $("input").val("");
        $("#totalPurchase").val(totalValue)
        $("#paymentInfo input[type='checkbox']").prop("checked", false);
    })
})