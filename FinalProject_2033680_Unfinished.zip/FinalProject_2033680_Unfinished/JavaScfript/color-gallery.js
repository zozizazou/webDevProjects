$(document).ready(function(){


    $(".liDescription img, #result-picture img").on('click', function(){

            let $imageLink = $(this).attr('src');
            window.open($imageLink, '_blank' )
    })


    $(".liDescription button, #go-top-button").on('click', function(){

        document.location.href = "#page-top";
    })

    $("#search-button").on('click', function(){

        if($("#images-search-input").val() == ''){

            $("#result-area-container").hide();

        }else{

            $("#result-area-container").show();
            
            let $userInput = $("#images-search-input").val().toLowerCase().replace(/\s/g, '');

            $("#result-picture-info h1").text($("#"+ $userInput + " h1").text());
            $("#result-picture-info p").text($("#"+ $userInput + " p").text());
            $("#result-picture img").attr("src", $("#"+ $userInput + " img").attr("src"));
        }
        
    })
    
})