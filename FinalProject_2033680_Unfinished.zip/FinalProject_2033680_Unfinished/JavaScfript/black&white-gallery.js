$(document).ready(function(){

    var $liDescriptionHeight = 300;
    // var 

    $(".liDescription img").on('click', function(){

        if($liDescriptionHeight == 300){
            $(".liDescription").height(600);
            $liDescriptionHeight = 600;
            $(".picInfo").show();
        }else{
            let $imageLink = $(this).attr('src');
            window.open($imageLink, '_blank' )
        }
    })

    $("main").on('click', function(e){

        if(e.target.tagName != "IMG" && e.target.tagName != "BUTTON"){

            $(".liDescription").height(300);
            $liDescriptionHeight = 300;
            $(".picInfo").hide();
        }
    })


    $(".liDescription button").on('click', function(){

        document.location.href = "#page-top";
    })
    
})