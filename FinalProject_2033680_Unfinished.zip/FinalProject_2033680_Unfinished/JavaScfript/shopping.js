$(document).ready(function(){


    $(".liDescription img, #result-picture img").on('click', function(){

            let $imageLink = $(this).attr('src');
            window.open($imageLink, '_blank' )
    })



        var $bw_BoxesChecked = 0;
        var $color_BoxesChecked = 0;
        var $blackAndWhite_subtotal = 0;
        var $color_subtotal = 0;
        var $totalQuantity = 0;


        $(".blackAndWhite-pictureSelector input[type='checkbox']").on('change', function(){

            if ($(this).is(':checked')){

                $bw_BoxesChecked += 1;

                if($bw_BoxesChecked == 4){
                    $(".blackAndWhite-pictureSelector :checkbox:not(:checked)").prop('disabled', true);
                    $(".blackAndWhite-pictureSelector :checkbox:not(:checked)").closest('li').find('.maxPicsReached').show();
                    $(".blackAndWhite-pictureSelector :checkbox:not(:checked)").closest('li').find('#numberOfCopies').prop('disabled', true);
                    $(".blackAndWhite-pictureSelector :checkbox:not(:checked)").closest('li').find('#numberOfCopies').val('');
                }

            } else {

                $bw_BoxesChecked -= 1;
                if($bw_BoxesChecked == 4){
                    $(".blackAndWhite-pictureSelector :checkbox:not(:checked)").prop('disabled', true);
                    $(".blackAndWhite-pictureSelector :checkbox:not(:checked)").closest('li').find('.maxPicsReached').hide();
                    $(".blackAndWhite-pictureSelector :checkbox:not(:checked)").closest('li').find('#numberOfCopies').prop('disabled', false);
                }

            }
        })



        $(".color-pictureSelector input[type='checkbox']").on('change', function(){

            if ($(this).is(':checked')){

                $color_BoxesChecked += 1;

                if($color_BoxesChecked === 4){

                    $(".color-pictureSelector :checkbox:not(:checked)").prop('disabled', true);
                    $(".color-pictureSelector :checkbox:not(:checked)").closest('li').find('.maxPicsReached').show();
                    $(".color-pictureSelector :checkbox:not(:checked)").closest('li').find('#numberOfCopies').prop('disabled', true);
                    $(".color-pictureSelector :checkbox:not(:checked)").closest('li').find('#numberOfCopies').val('');
                }

            } else {

                $color_BoxesChecked -= 1;
                
                if($color_BoxesChecked < 4){

                    $(".color-pictureSelector :checkbox:not(:checked)").prop('disabled', false);
                    $(".color-pictureSelector :checkbox:not(:checked)").closest('li').find('.maxPicsReached').hide();
                    $(".color-pictureSelector :checkbox:not(:checked)").closest('li').find('#numberOfCopies').prop('disabled', false);
                } 

            }
        })





        $('.add-button').on('click', function(){


            $(".blackAndWhite-pictureSelector :checkbox:checked").closest('li').each(function() {

                let numberOfCopies = parseInt($(this).find('#numberOfCopies').val()) || 0;
                let individualPicturePrice = parseInt($(this).find('#picturePrice').attr('custom-value')) || 0;
                let totalForEachPic = numberOfCopies * individualPicturePrice;

                $totalQuantity += numberOfCopies;

                $blackAndWhite_subtotal += totalForEachPic;
            });
            $('#blackAndWhite-subtotal').val($blackAndWhite_subtotal);



            $(".color-pictureSelector :checkbox:checked").closest('li').each(function() {

                let numberOfCopies = parseInt($(this).find('#numberOfCopies').val()) || 0;
                let individualPicturePrice = parseInt($(this).find('#picturePrice').attr('custom-value')) || 0;
                let totalForEachPic = numberOfCopies * individualPicturePrice;

                $totalQuantity += numberOfCopies;
                
                $color_subtotal += totalForEachPic;
            });
            $('#color-subtotal').val($color_subtotal);
            console.log("Total quantity is: " + $totalQuantity);

        })
        
        

        $("#invoice-button").on('click', function(){

            let subtotal = ($blackAndWhite_subtotal + $color_subtotal);

            localStorage.setItem('mySubtotal', subtotal);
            localStorage.setItem('myQuantity', $totalQuantity);


            window.location.href = "invoice.html";
        })
})