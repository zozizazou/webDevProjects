$(document).ready(function(){

    function loadPage(){
        window.location.href = "home.html";
    }

    setTimeout(loadPage, 6000);
})